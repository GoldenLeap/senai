function casquinha(){
    alert('Estamos em promoção, e por ter comprado uma casquinha, você recebeu mais uma.')
}
function picole(){
    alert('Parabens você ganhou um cupom de desconto de 20% na proxima compra.')
}